test = {
  'name': 'q1_12_0',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> pop_for_year(1972) == 3355562066
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pop_for_year(2020) == 6765161289
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pop_for_year(1989) == 4576679948
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> pop_for_year(2002) == 5514129422
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
